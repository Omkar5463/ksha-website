import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Product from './components/Product';
import Founders from './components/Founders';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  useEffect(() => {
    // Update the document title
    document.title = 'BioGen Power | Innovative Biogas Generators';
    
    // Add smooth scrolling behavior to the whole document
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Product />
      <Founders />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;