import React, { useState } from 'react';
import { content } from '../utils/constants';
import { Mail, Phone, MessageSquare, Send } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  
  const [formStatus, setFormStatus] = useState<{
    submitted: boolean;
    error: boolean;
    message: string;
  }>({
    submitted: false,
    error: false,
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // This would normally connect to a backend, but we'll simulate success
    setFormStatus({
      submitted: true,
      error: false,
      message: 'Thank you for your message! We will get back to you soon.',
    });

    // Reset form after successful submission
    setFormData({
      name: '',
      email: '',
      message: '',
    });
  };

  return (
    <section
      id="contact"
      className="py-20 bg-orange-50"
    >
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">
              {content.contact.heading}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {content.contact.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1 bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-6 text-gray-800 border-b border-orange-200 pb-4">
                Contact Information
              </h3>
              
              <div className="space-y-6">
                {content.founders.map((founder, index) => (
                  <div key={index} className="space-y-4">
                    <h4 className="font-medium text-orange-600">{founder.name}</h4>
                    
                    <div className="flex items-center text-gray-700">
                      <Phone size={18} className="mr-3 text-orange-500" />
                      <a 
                        href={`tel:${founder.contactPhone}`}
                        className="hover:text-orange-600 transition-colors duration-300"
                      >
                        {founder.contactPhone}
                      </a>
                    </div>
                    
                    <div className="flex items-center text-gray-700">
                      <Mail size={18} className="mr-3 text-orange-500" />
                      <a 
                        href={`mailto:${founder.contactEmail}`}
                        className="hover:text-orange-600 transition-colors duration-300 break-all"
                      >
                        {founder.contactEmail}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="md:col-span-2 bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold mb-6 text-gray-800 border-b border-orange-200 pb-4">
                Send us a Message
              </h3>
              
              {formStatus.submitted ? (
                <div className={`p-4 rounded-lg ${formStatus.error ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                  {formStatus.message}
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors duration-300"
                      placeholder="John Doe"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                      Your Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors duration-300"
                      placeholder="john@example.com"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                      Your Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors duration-300"
                      placeholder="I'm interested in learning more about your biogas generators..."
                    ></textarea>
                  </div>
                  
                  <div>
                    <button
                      type="submit"
                      className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-300 flex items-center"
                    >
                      <Send size={18} className="mr-2" />
                      {content.contact.cta}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;