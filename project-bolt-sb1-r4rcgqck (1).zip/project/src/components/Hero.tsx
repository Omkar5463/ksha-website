import React from 'react';
import { content } from '../utils/constants';

const Hero: React.FC = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  };

  return (
    <section 
      className="min-h-screen relative flex items-center"
      style={{
        background: 'linear-gradient(145deg, #FF7A00 15%, #FFA500 65%, #FF6B00 100%)',
      }}
    >
      <div 
        className="absolute inset-0 z-0 opacity-20"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/5207513/pexels-photo-5207513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      ></div>
      <div className="container mx-auto px-4 pt-16 relative z-10">
        <div className="max-w-3xl mx-auto text-center text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 animate-fade-in">
            {content.company.name}
          </h1>
          <p className="text-xl md:text-2xl mb-8 animate-fade-in-up opacity-90">
            {content.company.tagline}
          </p>
          <p className="text-lg mb-12 opacity-80 animate-fade-in-up delay-200">
            {content.company.description}
          </p>
          <div className="flex justify-center space-x-4 animate-fade-in-up delay-300">
            <button
              onClick={scrollToContact}
              className="bg-white text-orange-600 hover:bg-orange-100 transition-colors duration-300 font-semibold py-3 px-8 rounded-full transform hover:scale-105"
            >
              Contact Us
            </button>
            <button
              onClick={() => {
                const element = document.getElementById('product');
                if (element) {
                  element.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                  });
                }
              }}
              className="bg-transparent border-2 border-white text-white hover:bg-white/10 transition-colors duration-300 font-semibold py-3 px-8 rounded-full transform hover:scale-105"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce">
        <button
          onClick={() => {
            const element = document.getElementById('product');
            if (element) {
              element.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
              });
            }
          }}
          aria-label="Scroll down"
          className="text-white opacity-70 hover:opacity-100 transition-opacity duration-300"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 5v14M5 12l7 7 7-7" />
          </svg>
        </button>
      </div>
    </section>
  );
};

export default Hero;