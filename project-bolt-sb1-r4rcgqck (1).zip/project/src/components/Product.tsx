import React from 'react';
import { content } from '../utils/constants';
import { CheckCircle } from 'lucide-react';

const Product: React.FC = () => {
  return (
    <section
      id="product"
      className="py-20 bg-white"
    >
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex-1 order-2 md:order-1">
              <h2 className="text-3xl font-bold mb-6 text-gray-800">
                <span className="text-orange-600">Sustainable Energy</span> for a Better Future
              </h2>
              <h3 className="text-xl font-semibold mb-4 text-gray-700">
                {content.product.name}
              </h3>
              <p className="text-gray-600 mb-8 leading-relaxed">
                {content.product.description}
              </p>
              <div className="space-y-3">
                {content.product.features.map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="text-green-600 mr-2 mt-1 flex-shrink-0" size={20} />
                    <p className="text-gray-700">{feature}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1 order-1 md:order-2">
              <div className="relative">
                <div className="bg-orange-100 rounded-lg overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-300">
                  <img
                    src="https://images.pexels.com/photos/3976320/pexels-photo-3976320.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="Biogas Generator"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-orange-600/20 to-transparent"></div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-green-600 text-white py-2 px-4 rounded-lg shadow-md">
                  <span className="font-semibold">100% Renewable</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Product;