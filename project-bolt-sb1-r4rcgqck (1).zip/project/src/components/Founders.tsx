import React from 'react';
import { content } from '../utils/constants';
import { Mail, Phone } from 'lucide-react';

const Founders: React.FC = () => {
  return (
    <section
      id="founders"
      className="py-20 bg-gray-50"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-800">Meet Our <span className="text-orange-600">Founders</span></h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            The visionary team behind BioGen Power, dedicated to revolutionizing renewable energy through innovative biogas solutions.
          </p>
        </div>
        
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
          {content.founders.map((founder, index) => (
            <div 
              key={index}
              className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:translate-y-[-5px] transition-transform duration-300"
            >
              <div className="bg-orange-600 h-8"></div>
              <div className="p-6">
                <div className="flex items-start mb-4">
                  <div className="bg-gray-200 rounded-full w-16 h-16 flex items-center justify-center mr-4 overflow-hidden">
                    {/* Using first letter of founder name as a placeholder */}
                    <span className="text-2xl font-bold text-orange-600">
                      {founder.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">{founder.name}</h3>
                    <p className="text-orange-600 font-medium">{founder.role}</p>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {founder.description}
                </p>
                
                <div className="space-y-2">
                  <div className="flex items-center text-gray-700">
                    <Phone size={18} className="mr-2 text-orange-600" />
                    <a 
                      href={`tel:${founder.contactPhone}`}
                      className="hover:text-orange-600 transition-colors duration-300"
                    >
                      {founder.contactPhone}
                    </a>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Mail size={18} className="mr-2 text-orange-600" />
                    <a 
                      href={`mailto:${founder.contactEmail}`}
                      className="hover:text-orange-600 transition-colors duration-300"
                    >
                      {founder.contactEmail}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Founders;