export const colors = {
  primary: {
    50: '#FFF7ED',
    100: '#FFEDD5',
    200: '#FED7AA',
    300: '#FDBA74',
    400: '#FB923C',
    500: '#F97316',
    600: '#EA580C',
    700: '#C2410C',
    800: '#9A3412',
    900: '#7C2D12',
  },
  secondary: {
    50: '#ECFDF5',
    100: '#D1FAE5',
    200: '#A7F3D0',
    300: '#6EE7B7',
    400: '#34D399',
    500: '#10B981',
    600: '#059669',
    700: '#047857',
    800: '#065F46',
    900: '#064E3B',
  },
  neutral: {
    50: '#F9FAFB',
    100: '#F3F4F6',
    200: '#E5E7EB',
    300: '#D1D5DB',
    400: '#9CA3AF',
    500: '#6B7280',
    600: '#4B5563',
    700: '#374151',
    800: '#1F2937',
    900: '#111827',
  },
};

export const content = {
  company: {
    name: 'Ksha',
    tagline: 'Innovative Biogas Generators Powered by Clean Energy',
    description: 'Harnessing the power of renewable biogas for a sustainable future.',
  },
  product: {
    name: '5kVA Biogas Generator',
    description: 'Our flagship 5kVA biogas generator runs entirely on renewable biogas, transforming organic waste into clean, reliable energy. Designed with sustainability and efficiency in mind, our generators reduce carbon footprint while providing dependable power for homes, farms, and small businesses.',
    features: [
      'Runs 100% on renewable biogas',
      'Compact and efficient 5kVA output',
      'Low maintenance design',
      'Reduces waste and carbon emissions',
      'Sustainable alternative to fossil fuels',
    ],
  },
  founders: [
    {
      name: 'Aryan Khillari',
      role: 'CEO & CTO',
      description: 'With expertise in renewable energy technologies, Aryan leads our technical innovation and overall company vision, driving Ksha to create cutting-edge biogas solutions.',
      contactEmail: 'askhilari433@gmail.com',
      contactPhone: '+91 9881626641',
    },
    {
      name: 'Omkar Dhengale',
      role: 'CFO & COO',
      description: 'Omkar manages our financial strategies and daily operations, ensuring Ksha delivers exceptional value and service to all our customers.',
      contactEmail: 'dhengaleomkaroff@gmail.com',
      contactPhone: '+91 7038668345',
    },
  ],
  contact: {
    heading: 'Get in Touch',
    description: 'Interested in learning more about our biogas generators? We\'d love to hear from you! Contact us to discuss how our renewable energy solutions can meet your needs.',
    cta: 'Contact Us Today',
  },
};